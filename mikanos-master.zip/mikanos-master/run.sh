#!/bin/sh

. $HOME/osbook/devenv/buildenv.sh
APPS_DIR=./apps RESOURCE_DIR=./resource ./build.sh run
