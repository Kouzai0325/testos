#pragma once

void InitializeSyscall();
